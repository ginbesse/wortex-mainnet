package api

import (
	"encoding/json"
	"io"
	"net"
	"net/http"
	"net/url"
	"os"
	"strconv"
	"strings"
	"sync"
	"time"
)

type Config struct{ RPCURL, APIKey, AllowedOrigin string }
type API struct {
	cfg     Config
	client  *http.Client
	limiter *limiter
}

func New(cfg Config) http.Handler {
	a := &API{cfg: cfg, client: &http.Client{Timeout: 8 * time.Second}, limiter: newLimiter(requestLimit())}
	mux := http.NewServeMux()
	mux.HandleFunc("GET /healthz", a.health)
	mux.HandleFunc("GET /v1/status", a.status)
	mux.HandleFunc("GET /v1/block/{height}", a.block)
	mux.HandleFunc("GET /v1/tx/{hash}", a.tx)
	return a.middleware(mux)
}
func (a *API) health(w http.ResponseWriter, r *http.Request) {
	writeJSON(w, 200, map[string]any{"ok": true, "service": "wortex-api"})
}
func (a *API) status(w http.ResponseWriter, r *http.Request) { a.proxyRPC(w, r, "/status") }
func (a *API) block(w http.ResponseWriter, r *http.Request) {
	height := r.PathValue("height")
	n, err := strconv.ParseUint(height, 10, 64)
	if err != nil || n == 0 {
		writeError(w, 400, "height must be a positive integer")
		return
	}
	a.proxyRPC(w, r, "/block?height="+url.QueryEscape(height))
}
func (a *API) tx(w http.ResponseWriter, r *http.Request) {
	hash := strings.ToUpper(strings.TrimSpace(r.PathValue("hash")))
	if len(hash) < 8 || len(hash) > 128 {
		writeError(w, 400, "transaction hash length is invalid")
		return
	}
	for _, c := range hash {
		if !strings.ContainsRune("0123456789ABCDEF", c) {
			writeError(w, 400, "transaction hash must be hexadecimal")
			return
		}
	}
	a.proxyRPC(w, r, "/tx?hash=0x"+url.QueryEscape(hash))
}
func (a *API) proxyRPC(w http.ResponseWriter, r *http.Request, path string) {
	target, err := url.Parse(a.cfg.RPCURL)
	if err != nil || (target.Scheme != "http" && target.Scheme != "https") || target.Host == "" {
		writeError(w, 500, "RPC URL configuration is invalid")
		return
	}
	target.Path = strings.TrimRight(target.Path, "/") + path
	req, err := http.NewRequestWithContext(r.Context(), http.MethodGet, target.String(), nil)
	if err != nil {
		writeError(w, 500, "could not create RPC request")
		return
	}
	resp, err := a.client.Do(req)
	if err != nil {
		writeError(w, 502, "configured RPC node is unavailable")
		return
	}
	defer resp.Body.Close()
	w.Header().Set("Content-Type", "application/json")
	w.Header().Set("Cache-Control", "no-store")
	w.WriteHeader(resp.StatusCode)
	_, _ = io.Copy(w, io.LimitReader(resp.Body, 2<<20))
}
func (a *API) middleware(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("X-Content-Type-Options", "nosniff")
		w.Header().Set("Referrer-Policy", "no-referrer")
		if a.cfg.AllowedOrigin != "" && r.Header.Get("Origin") == a.cfg.AllowedOrigin {
			w.Header().Set("Access-Control-Allow-Origin", a.cfg.AllowedOrigin)
			w.Header().Set("Vary", "Origin")
		}
		if r.URL.Path != "/healthz" {
			if !a.limiter.allow(clientIP(r)) {
				writeError(w, 429, "rate limit exceeded")
				return
			}
			if a.cfg.APIKey != "" && r.Header.Get("Authorization") != "Bearer "+a.cfg.APIKey {
				writeError(w, 401, "valid bearer API key required")
				return
			}
		}
		next.ServeHTTP(w, r)
	})
}
func clientIP(r *http.Request) string {
	host, _, err := net.SplitHostPort(r.RemoteAddr)
	if err == nil {
		return host
	}
	return r.RemoteAddr
}
func writeJSON(w http.ResponseWriter, status int, v any) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(status)
	_ = json.NewEncoder(w).Encode(v)
}
func writeError(w http.ResponseWriter, status int, msg string) {
	writeJSON(w, status, map[string]string{"error": msg})
}
func requestLimit() int {
	n, err := strconv.Atoi(os.Getenv("WORTEX_MAX_REQUESTS_PER_MINUTE"))
	if err != nil || n < 1 {
		return 120
	}
	return n
}

type limiter struct {
	mu      sync.Mutex
	max     int
	buckets map[string]bucket
}
type bucket struct {
	count int
	start time.Time
}

func newLimiter(max int) *limiter { return &limiter{max: max, buckets: map[string]bucket{}} }
func (l *limiter) allow(ip string) bool {
	now := time.Now()
	l.mu.Lock()
	defer l.mu.Unlock()
	b, ok := l.buckets[ip]
	if !ok || now.Sub(b.start) >= time.Minute {
		b = bucket{start: now}
	}
	b.count++
	l.buckets[ip] = b
	return b.count <= l.max
}
