package api

import (
	"net/http"
	"net/http/httptest"
	"testing"
)

func TestHealth(t *testing.T) {
	h := New(Config{RPCURL: "http://127.0.0.1:26657"})
	r := httptest.NewRequest(http.MethodGet, "/healthz", nil)
	w := httptest.NewRecorder()
	h.ServeHTTP(w, r)
	if w.Code != 200 {
		t.Fatalf("status=%d", w.Code)
	}
}
func TestBlockRejectsInvalidHeight(t *testing.T) {
	h := New(Config{RPCURL: "http://127.0.0.1:26657"})
	r := httptest.NewRequest(http.MethodGet, "/v1/block/abc", nil)
	w := httptest.NewRecorder()
	h.ServeHTTP(w, r)
	if w.Code != 400 {
		t.Fatalf("status=%d", w.Code)
	}
}
func TestAPIKeyRequired(t *testing.T) {
	h := New(Config{RPCURL: "http://127.0.0.1:26657", APIKey: "secret"})
	r := httptest.NewRequest(http.MethodGet, "/v1/status", nil)
	w := httptest.NewRecorder()
	h.ServeHTTP(w, r)
	if w.Code != 401 {
		t.Fatalf("status=%d", w.Code)
	}
}
