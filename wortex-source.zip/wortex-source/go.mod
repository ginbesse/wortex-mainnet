module github.com/wortex-mainnet/wortex

go 1.23
