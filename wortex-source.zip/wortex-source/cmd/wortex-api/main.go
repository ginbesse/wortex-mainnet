package main

import (
	"log"
	"net/http"
	"os"
	"strings"
	"time"

	"github.com/wortex-mainnet/wortex/internal/api"
)

func main() {
	rpcURL := strings.TrimRight(os.Getenv("WORTEX_RPC_URL"), "/")
	if rpcURL == "" {
		log.Fatal("WORTEX_RPC_URL must point to a trusted Cosmos/CometBFT RPC node")
	}
	addr := os.Getenv("WORTEX_API_ADDR")
	if addr == "" {
		addr = "127.0.0.1:8080"
	}
	handler := api.New(api.Config{RPCURL: rpcURL, APIKey: os.Getenv("WORTEX_API_KEY"), AllowedOrigin: os.Getenv("WORTEX_ALLOWED_ORIGIN")})
	srv := &http.Server{Addr: addr, Handler: handler, ReadHeaderTimeout: 5 * time.Second, ReadTimeout: 10 * time.Second, WriteTimeout: 20 * time.Second, IdleTimeout: 60 * time.Second}
	log.Printf("WORTEX API listening on %s", addr)
	log.Fatal(srv.ListenAndServe())
}
