# WORTEX Source — API foundation

A buildable Go API service that reads data from a configured Cosmos-compatible RPC node. It does not invent balances, prices, reserves, or USD value.

## Endpoints
- `GET /healthz` — process health
- `GET /v1/status` — node status from configured RPC
- `GET /v1/block/{height}` — block data from configured RPC
- `GET /v1/tx/{hash}` — transaction lookup from configured RPC

## Run locally
Requires Go 1.23+ and a trusted, reachable Cosmos/CometBFT RPC node.

```bash
export WORTEX_RPC_URL="http://127.0.0.1:26657"
go test ./...
go run ./cmd/wortex-api
```

Then try `curl http://127.0.0.1:8080/healthz` and `curl http://127.0.0.1:8080/v1/status`.
If no RPC node is running, chain-data endpoints return 502 instead of fabricated data.

## Configuration
- `WORTEX_RPC_URL` — required base URL of trusted RPC
- `WORTEX_API_ADDR` — bind address, default `127.0.0.1:8080`
- `WORTEX_ALLOWED_ORIGIN` — optional single CORS origin
- `WORTEX_API_KEY` — optional bearer key required for `/v1/*`; never commit secrets
- `WORTEX_MAX_REQUESTS_PER_MINUTE` — per-client in-memory limit, default 120

## Important
This is an API service, **not a launched WORTEX blockchain or mainnet**. Real chain data appears only if the RPC URL points to a running, trusted chain node. A public mainnet still needs chain software, genesis, multiple independent validators, public infrastructure, monitoring, and security review. Token supply is not USD reserves or market value.

Before selling API access, add HTTPS, durable/distributed rate limiting, customer billing, monitoring, abuse controls, and terms/privacy disclosures. Never expose validator signing keys or commit secrets.
